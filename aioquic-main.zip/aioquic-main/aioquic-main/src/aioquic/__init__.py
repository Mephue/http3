# flake8: noqa

from .about import __version__
